import { useEffect, useMemo, useState } from 'react'
import {
  GraduationCap, Moon, Sun, ArrowRight, Calculator, ChartNoAxesCombined,
  BookOpen, Users, Download, Printer, Plus, Trash2, Search, Sparkles,
  CheckCircle2, CircleAlert, TrendingUp, Menu, X, RotateCcw
} from 'lucide-react'

const defaultSubjects = [
  { id: 1, name: 'Mathematics', marks: '92', max: '100' },
  { id: 2, name: 'Computer Science', marks: '96', max: '100' },
  { id: 3, name: 'Database Systems', marks: '88', max: '100' },
  { id: 4, name: 'Operating Systems', marks: '85', max: '100' },
  { id: 5, name: 'Communication Skills', marks: '90', max: '100' },
]
const sampleStudents = [
  { id: 1, name: 'Ananya Sharma', roll: 'CS2026001', percentage: 92.2, grade: 'A+', status: 'Pass' },
  { id: 2, name: 'Rahul Kumar', roll: 'CS2026002', percentage: 78.4, grade: 'B+', status: 'Pass' },
  { id: 3, name: 'Priya Nair', roll: 'CS2026003', percentage: 88.6, grade: 'A', status: 'Pass' },
]
const gradeFor = p => p >= 90 ? 'A+' : p >= 80 ? 'A' : p >= 70 ? 'B+' : p >= 60 ? 'B' : p >= 50 ? 'C' : p >= 40 ? 'D' : 'F'
const gradeColor = g => g === 'A+' || g === 'A' ? 'good' : g === 'F' ? 'bad' : 'mid'

export default function App() {
  const [dark, setDark] = useState(true)
  const [page, setPage] = useState('home')
  const [student, setStudent] = useState({ name: '', roll: '', department: 'Computer Science', semester: 'Semester 5' })
  const [subjects, setSubjects] = useState(defaultSubjects)
  const [students, setStudents] = useState(() => {
    try { return JSON.parse(localStorage.getItem('gradepro-students')) || sampleStudents } catch { return sampleStudents }
  })
  const [query, setQuery] = useState('')
  const [showForm, setShowForm] = useState(false)
  const [mobileNav, setMobileNav] = useState(false)

  useEffect(() => { localStorage.setItem('gradepro-students', JSON.stringify(students)) }, [students])

  const result = useMemo(() => {
    const rows = subjects.map(s => ({ ...s, marksNum: Number(s.marks), maxNum: Number(s.max) }))
    const valid = rows.every(s => s.name.trim() && s.marks !== '' && s.max !== '' &&
      Number.isFinite(s.marksNum) && Number.isFinite(s.maxNum) && s.maxNum > 0 &&
      s.marksNum >= 0 && s.marksNum <= s.maxNum)
    const total = rows.reduce((sum, s) => sum + (Number.isFinite(s.marksNum) ? s.marksNum : 0), 0)
    const maxTotal = rows.reduce((sum, s) => sum + (Number.isFinite(s.maxNum) && s.maxNum > 0 ? s.maxNum : 0), 0)
    const percentage = maxTotal ? total / maxTotal * 100 : 0
    const passed = valid && rows.length > 0 && rows.every(s => s.marksNum / s.maxNum * 100 >= 40)
    return { rows, valid, total, maxTotal, percentage, grade: gradeFor(percentage), gpa: Math.min(10, percentage / 10), passed }
  }, [subjects])

  const updateSubject = (id, field, value) => setSubjects(current => current.map(s => s.id === id ? { ...s, [field]: value } : s))
  const addSubject = () => setSubjects(current => [...current, { id: Date.now(), name: '', marks: '', max: '100' }])
  const removeSubject = id => setSubjects(current => current.length > 1 ? current.filter(s => s.id !== id) : current)
  const beginCalculator = () => { setPage('calculator'); window.scrollTo({ top: 0, behavior: 'smooth' }) }
  const saveResult = () => {
    if (!result.valid || !student.name.trim() || !student.roll.trim()) {
      alert('Please enter the student name, roll number, and valid marks for every subject.')
      return
    }
    const record = { id: Date.now(), name: student.name.trim(), roll: student.roll.trim(),
      percentage: Number(result.percentage.toFixed(1)), grade: result.grade, status: result.passed ? 'Pass' : 'Fail' }
    setStudents(current => [record, ...current.filter(s => s.roll !== record.roll)])
    setPage('results')
  }
  const downloadCSV = () => {
    const rows = [
      ['Student Grade Report'], ['Student Name', student.name], ['Roll Number', student.roll],
      ['Department', student.department], ['Semester', student.semester], [],
      ['Subject', 'Marks Obtained', 'Maximum Marks', 'Percentage'],
      ...result.rows.map(s => [s.name, s.marks, s.max, s.maxNum > 0 ? (s.marksNum / s.maxNum * 100).toFixed(2) + '%' : '']),
      [], ['Total', result.total, result.maxTotal], ['Percentage', result.percentage.toFixed(2) + '%'],
      ['Grade', result.grade], ['GPA (estimated)', result.gpa.toFixed(2)], ['Status', result.passed ? 'Pass' : 'Fail']
    ]
    const csv = rows.map(row => row.map(cell => `"${String(cell ?? '').replaceAll('"', '""')}"`).join(',')).join('\n')
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8;' }))
    const a = document.createElement('a'); a.href = url; a.download = 'gradepro-student-report.csv'; a.click()
    URL.revokeObjectURL(url)
  }
  const filtered = students.filter(s => `${s.name} ${s.roll}`.toLowerCase().includes(query.toLowerCase()))
  const nav = [
    { id: 'home', label: 'Home', icon: BookOpen },
    { id: 'calculator', label: 'Grade Calculator', icon: Calculator },
    { id: 'results', label: 'Student Results', icon: ChartNoAxesCombined },
  ]

  return <div className={dark ? 'app dark' : 'app light'}>
    <header className="topbar">
      <button className="brand" onClick={() => setPage('home')} aria-label="GradePro home">
        <span className="brand-icon"><GraduationCap size={23}/></span>
        <span>Grade<span className="brand-accent">Pro</span><small>STUDENT PERFORMANCE</small></span>
      </button>
      <nav className={mobileNav ? 'nav open' : 'nav'}>
        {nav.map(n => <button key={n.id} className={page === n.id ? 'nav-link active' : 'nav-link'} onClick={() => { setPage(n.id); setMobileNav(false) }}><n.icon size={16}/>{n.label}</button>)}
      </nav>
      <div className="top-actions">
        <button className="icon-button" onClick={() => setDark(!dark)} aria-label="Toggle theme">{dark ? <Sun size={18}/> : <Moon size={18}/>}</button>
        <button className="mobile-menu icon-button" onClick={() => setMobileNav(!mobileNav)} aria-label="Toggle menu">{mobileNav ? <X size={20}/> : <Menu size={20}/>}</button>
        <button className="top-cta" onClick={beginCalculator}>Get Started <ArrowRight size={16}/></button>
      </div>
    </header>

    <main>
      {page === 'home' && <section className="hero page-width">
        <div className="hero-copy">
          <div className="eyebrow"><Sparkles size={14}/> SMARTER ACADEMIC TRACKING</div>
          <h1>Know your performance.<br/><span>Shape your future.</span></h1>
          <p className="hero-description">Your academic journey, made clearer. Calculate grades, track your progress, and turn every mark into a step forward.</p>
          <div className="hero-buttons">
            <button className="primary-button" onClick={beginCalculator}>Calculate My Grade <ArrowRight size={17}/></button>
            <button className="secondary-button" onClick={() => setPage('results')}>Explore Dashboard</button>
          </div>
          <div className="trust-row"><span className="avatar-stack"><i>B</i><i>A</i><i>P</i></span><span><b>Simple. Accurate. Student-first.</b><small>Everything you need in one place.</small></span></div>
        </div>
        <div className="hero-art">
          <div className="glow-orb"></div>
          <div className="float-chip chip-one"><span className="chip-symbol green"><TrendingUp size={17}/></span><span><small>Performance</small><b>Looking great!</b></span></div>
          <div className="preview-card">
            <div className="preview-top"><span className="preview-icon"><ChartNoAxesCombined size={19}/></span><span><b>Academic Overview</b><small>Sample student report</small></span><span className="dots">•••</span></div>
            <div className="preview-score"><div><small>Overall percentage</small><strong>92.4<span>%</span></strong><em><TrendingUp size={13}/> Excellent progress</em></div><div className="ring"><span>A+<small>GRADE</small></span></div></div>
            <div className="mini-bars"><div><span>Mathematics</span><i><b style={{width:'92%'}}/></i><strong>92</strong></div><div><span>Computer Science</span><i><b style={{width:'96%'}}/></i><strong>96</strong></div><div><span>Database Systems</span><i><b style={{width:'88%'}}/></i><strong>88</strong></div></div>
            <div className="preview-bottom"><span><CheckCircle2 size={15}/> All subjects recorded</span><span>View report <ArrowRight size={13}/></span></div>
          </div>
          <div className="float-chip chip-two"><span className="chip-symbol purple"><GraduationCap size={18}/></span><span><small>Grade point</small><b>9.2 / 10</b></span></div>
          <div className="decor decor-one">✳</div><div className="decor decor-two">✦</div>
        </div>
        <div className="feature-strip">
          <div><span className="feature-icon violet"><Calculator size={20}/></span><span><b>Instant calculation</b><small>Total, percentage & grade</small></span></div>
          <div><span className="feature-icon blue"><ChartNoAxesCombined size={20}/></span><span><b>Clear insights</b><small>Understand your results</small></span></div>
          <div><span className="feature-icon green"><Download size={20}/></span><span><b>Export reports</b><small>Download and print easily</small></span></div>
        </div>
      </section>}

      {page === 'calculator' && <section className="page-width workspace">
        <div className="section-heading"><div><div className="eyebrow"><Calculator size={14}/> GRADE CALCULATOR</div><h1>Calculate your grade</h1><p>Enter student details and marks to generate an instant academic report.</p></div><button className="secondary-button" onClick={() => {setStudent({name:'',roll:'',department:'Computer Science',semester:'Semester 5'});setSubjects(defaultSubjects)}}><RotateCcw size={15}/> Reset form</button></div>
        <div className="calculator-layout">
          <div className="form-column">
            <section className="panel">
              <div className="panel-title"><span className="number-icon">01</span><div><h2>Student information</h2><p>Enter the student's basic details</p></div></div>
              <div className="field-grid">
                <label>Full name<input value={student.name} onChange={e=>setStudent({...student,name:e.target.value})} placeholder="e.g. Bhavani T" /></label>
                <label>Roll number<input value={student.roll} onChange={e=>setStudent({...student,roll:e.target.value})} placeholder="e.g. CS2026001" /></label>
                <label>Department<select value={student.department} onChange={e=>setStudent({...student,department:e.target.value})}><option>Computer Science</option><option>Information Technology</option><option>Electronics and Communication</option><option>Electrical Engineering</option><option>Mechanical Engineering</option><option>Other</option></select></label>
                <label>Semester<select value={student.semester} onChange={e=>setStudent({...student,semester:e.target.value})}>{Array.from({length:8},(_,i)=><option key={i}>Semester {i+1}</option>)}</select></label>
              </div>
            </section>
            <section className="panel">
              <div className="panel-title subject-heading"><span className="number-icon">02</span><div><h2>Subject marks</h2><p>Add each subject and its marks</p></div><button className="small-add" onClick={addSubject}><Plus size={15}/> Add subject</button></div>
              <div className="marks-table">
                <div className="marks-header"><span>SUBJECT NAME</span><span>MARKS</span><span>OUT OF</span><span></span></div>
                {subjects.map((s,i)=><div className="marks-row" key={s.id}>
                  <span className="subject-index">{String(i+1).padStart(2,'0')}</span>
                  <input className="subject-name" value={s.name} onChange={e=>updateSubject(s.id,'name',e.target.value)} placeholder="Subject name" aria-label="Subject name"/>
                  <input type="number" min="0" max={s.max} value={s.marks} onChange={e=>updateSubject(s.id,'marks',e.target.value)} aria-label="Marks obtained"/>
                  <input type="number" min="1" value={s.max} onChange={e=>updateSubject(s.id,'max',e.target.value)} aria-label="Maximum marks"/>
                  <button className="remove-button" onClick={()=>removeSubject(s.id)} title="Remove subject" aria-label="Remove subject"><Trash2 size={15}/></button>
                </div>)}
              </div>
              {!result.valid && <p className="validation"><CircleAlert size={15}/> Check that subject names and marks are valid, and marks do not exceed maximum marks.</p>}
              <div className="form-footer"><span><CheckCircle2 size={15}/> Results update automatically</span><button className="primary-button" onClick={saveResult}>Save & View Results <ArrowRight size={16}/></button></div>
            </section>
          </div>
          <aside className="summary-panel">
            <div className="summary-heading"><span className="summary-icon"><Sparkles size={18}/></span><div><h2>Live summary</h2><p>Your results at a glance</p></div></div>
            <div className="big-score"><small>Overall percentage</small><strong>{result.percentage.toFixed(1)}<span>%</span></strong><div className="progress-track"><i style={{width:`${Math.min(100,result.percentage)}%`}}/></div><span className="score-caption">{result.percentage >= 80 ? 'Excellent work — keep it up!' : result.percentage >= 60 ? 'Good progress — keep improving!' : 'Every mark is a chance to improve.'}</span></div>
            <div className="summary-metrics"><div><span>Total marks</span><b>{result.total} <small>/ {result.maxTotal}</small></b></div><div><span>Grade</span><b className={`grade-text ${gradeColor(result.grade)}`}>{result.grade}</b></div><div><span>Estimated GPA</span><b>{result.gpa.toFixed(2)} <small>/ 10</small></b></div></div>
            <div className={`status-box ${result.passed ? 'status-pass' : 'status-fail'}`}><span>{result.passed ? <CheckCircle2 size={18}/> : <CircleAlert size={18}/>}</span><div><b>{result.passed ? 'Pass status' : 'Needs attention'}</b><small>{result.passed ? 'All subjects meet the 40% pass threshold.' : 'At least one subject may be below 40%.'}</small></div></div>
            <div className="summary-actions"><button className="secondary-button full-button" onClick={downloadCSV}><Download size={16}/> Download report (CSV)</button><button className="secondary-button full-button" onClick={()=>window.print()}><Printer size={16}/> Print report</button></div>
            <p className="fine-print">GPA is an estimate calculated as percentage ÷ 10. Adjust grading rules to match your institution.</p>
          </aside>
        </div>
      </section>}

      {page === 'results' && <section className="page-width workspace">
        <div className="section-heading"><div><div className="eyebrow"><ChartNoAxesCombined size={14}/> RESULTS DASHBOARD</div><h1>Student performance</h1><p>Review saved grade reports and keep academic progress organized.</p></div><button className="primary-button" onClick={beginCalculator}><Plus size={16}/> Add new result</button></div>
        <div className="dashboard-cards"><div className="stat-card"><span className="stat-icon violet"><Users size={19}/></span><small>Saved students</small><strong>{students.length}</strong><em>Stored on this device</em></div><div className="stat-card"><span className="stat-icon green"><CheckCircle2 size={19}/></span><small>Passing students</small><strong>{students.filter(s=>s.status==='Pass').length}</strong><em>Based on saved reports</em></div><div className="stat-card"><span className="stat-icon blue"><TrendingUp size={19}/></span><small>Average percentage</small><strong>{students.length ? (students.reduce((a,s)=>a+s.percentage,0)/students.length).toFixed(1)+'%' : '—'}</strong><em>Across saved reports</em></div></div>
        <section className="panel results-panel"><div className="results-toolbar"><div><h2>Student results</h2><p>Search, review, or remove a saved result.</p></div><div className="search-box"><Search size={16}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search name or roll no."/></div></div>
          <div className="results-table-wrap"><table><thead><tr><th>STUDENT</th><th>ROLL NUMBER</th><th>PERCENTAGE</th><th>GRADE</th><th>STATUS</th><th>ACTION</th></tr></thead><tbody>
            {filtered.map(s=><tr key={s.id}><td><span className="student-avatar">{s.name.split(' ').map(x=>x[0]).join('').slice(0,2).toUpperCase()}</span><b>{s.name}</b></td><td>{s.roll}</td><td><b>{Number(s.percentage).toFixed(1)}%</b></td><td><span className={`grade-pill ${gradeColor(s.grade)}`}>{s.grade}</span></td><td><span className={`status-pill ${s.status==='Pass'?'pass':'fail'}`}>{s.status}</span></td><td><button className="remove-button" aria-label={`Delete ${s.name}`} onClick={()=>setStudents(current=>current.filter(x=>x.id!==s.id))}><Trash2 size={15}/></button></td></tr>)}
            {!filtered.length && <tr><td colSpan="6" className="empty-state">No student results found. Add a result from the grade calculator.</td></tr>}
          </tbody></table></div><p className="fine-print">Saved results use your browser's local storage. They are not uploaded to a server.</p>
        </section>
      </section>}
    </main>
    <footer className="footer"><div className="footer-brand"><span className="brand-icon"><GraduationCap size={20}/></span><b>GradePro</b></div><span>Made for students who want to grow.</span><span>© {new Date().getFullYear()} GradePro</span></footer>
  </div>
}