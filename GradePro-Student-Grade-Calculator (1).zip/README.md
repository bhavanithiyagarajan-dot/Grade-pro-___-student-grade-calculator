# GradePro — Student Grade Calculator

A responsive React + Vite student grade calculator with a landing page, live mark calculations, saved student results, dark/light theme, CSV export, and print support.

## Features
- Premium responsive landing page
- Student name, roll number, department, and semester fields
- Add/remove subjects and enter different maximum marks
- Automatic total, percentage, estimated GPA, grade, and pass/fail status
- Student results dashboard with search and delete
- Saves result records in browser local storage
- Download a CSV report and print the report
- Dark/light theme toggle
- Mobile navigation and responsive layout

## Grade rules
- A+: 90–100%
- A: 80–89.99%
- B+: 70–79.99%
- B: 60–69.99%
- C: 50–59.99%
- D: 40–49.99%
- F: below 40%

The app currently uses a 40% pass threshold per subject and estimates GPA as percentage divided by 10. These are examples; change the rules in `src/App.jsx` to match your college's official grading policy.

## Run locally
Install Node.js (LTS), extract this ZIP, open a terminal in the project folder, and run:

```bash
npm install
npm run dev
```

Open the local URL shown in the terminal, usually `http://localhost:5173`.

## Build for deployment
```bash
npm run build
npm run preview
```

The production website is generated in the `dist` folder.

## Publish with GitHub Pages
1. Create a GitHub repository and upload the extracted project files (not the ZIP itself).
2. In the repository, go to **Settings → Pages** and choose **GitHub Actions**.
3. Create `.github/workflows/deploy.yml` using the workflow below.
4. Push the workflow file. GitHub Actions will build and publish the site.

```yaml
name: Deploy GradePro
on:
  push:
    branches: [main]
  workflow_dispatch:
permissions:
  contents: read
  pages: write
  id-token: write
concurrency:
  group: pages
  cancel-in-progress: true
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: npm
      - run: npm install
      - run: npm run build
      - uses: actions/upload-pages-artifact@v3
        with:
          path: dist
  deploy:
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    runs-on: ubuntu-latest
    needs: build
    steps:
      - id: deployment
        uses: actions/deploy-pages@v4
```

If the repository is a project site, set `base` in `vite.config.js` to `'/YOUR-REPOSITORY-NAME/'` (including the slashes) before building. Replace `YOUR-REPOSITORY-NAME` with the exact repository name.

## Data and privacy
Saved student results are stored in local browser storage on the device. This starter project has no server or cloud database.
